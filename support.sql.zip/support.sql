-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 28, 2024 at 02:07 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `support`
--

CREATE TABLE `support` (
  `id` int(11) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `s_number` int(100) NOT NULL,
  `s_email` varchar(100) NOT NULL,
  `s_discription` varchar(255) NOT NULL,
  `t_request` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `support`
--

INSERT INTO `support` (`id`, `s_name`, `s_number`, `s_email`, `s_discription`, `t_request`) VALUES
(20, 'Kent Ian Molinyawe', 123123, 'k@gmail.com', 'asdas', 'Incident R'),
(21, 'Kent Ian', 2020202, 'k@gmail.com', '404', 'Service Re'),
(22, 'Kent Ian Molinaywe', 2147483647, 'I@gmail.com', 'asdjklhasdojasdhaosdhaksdh askjdhaskjd askjdaskdjh asdkjashd askjdhaksdjj aksjdhkasdhj asoduih asdjh asd', 'Service Re'),
(23, 'asdasd', 123123, 'asd@gmail.com', 'asdasd', 'Service<br'),
(24, 'adrian adona ', 987654321, 'a@gmail.com', 'having an error 404', 'Incident R'),
(25, 'kasdasd', 123123, 'asd@gmail.com', 'asdasd', 'Service Re');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `support`
--
ALTER TABLE `support`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `support`
--
ALTER TABLE `support`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
